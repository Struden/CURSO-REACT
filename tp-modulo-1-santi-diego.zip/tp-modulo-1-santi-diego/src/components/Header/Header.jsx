import React from "react";
import './Header.css';

const Header = () => {
  return (
    <header>
      <h1>TP MODULO 1</h1>
    </header>
  );
};

export { Header };