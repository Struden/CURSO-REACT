import React from "react";
import './Footer.css'

const Footer = ()=>{
    return(
       <footer>
        <p>Programado por Diego Santi</p>
       </footer>
    )
}

export {Footer}
